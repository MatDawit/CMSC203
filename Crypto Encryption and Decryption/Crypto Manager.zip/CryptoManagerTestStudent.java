
import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

public class CryptoManagerTestStudent {
	CryptoManager cryptoManager;

	@Test
	public void testStringInBounds() {
		assertTrue(CryptoManager.isStringInBounds("ECLIPSE"));
		assertTrue(CryptoManager.isStringInBounds("CODING IN ECLIPSE"));
		assertFalse(CryptoManager.isStringInBounds("eclipse"));
		assertFalse(CryptoManager.isStringInBounds("{ECLIPSE"));
		assertFalse(CryptoManager.isStringInBounds("\"THIS SHOULD NOT WORK{ IT IS OUTSIDE THE RANGE\""));
	}

	@Test
	public void testEncryptCaesar() {
		assertEquals("ZRNH#ZRUOG", CryptoManager.caesarEncryption("WOKE WORLD", 3));
		assertEquals("[\\]", CryptoManager.caesarEncryption("XYZ", 3));
		assertEquals("9;,", CryptoManager.caesarEncryption("UWH", 100));
		assertEquals("E6GN8/D/", CryptoManager.caesarEncryption("WHY JAVA", 430));
		assertEquals("!,% +7+\\*+ %^", CryptoManager.caesarEncryption("JUNIT TESTING", 23));
		assertEquals("6CDI=:GU?JC>IUI:HI>C<", CryptoManager.caesarEncryption("ANOTHER JUNIT TESTING", 53));
	}

	@Test
	public void testDecryptCaesar() {
		assertEquals("WOKE WORLD", CryptoManager.caesarDecryption("ZRNH#ZRUOG", 3));
		assertEquals("XYZ", CryptoManager.caesarDecryption("[\\]", 3));
		assertEquals("UWH", CryptoManager.caesarDecryption("9;,", 100));
		assertEquals("JUNIT TESTING", CryptoManager.caesarDecryption("!,% +7+\\*+ %^", 23));
	}

	@Test
	public void testEncryptBellaso() {
		assertEquals("Z\\^H#$\"UOQ", CryptoManager.bellasoEncryption("WOKE WORLD", "CMSC"));
		assertEquals("TV$J^!*F]U_OQ", CryptoManager.bellasoEncryption("JUNIT TESTING", "JAVA"));
		assertEquals("TV$J4^Z!]]X\\", CryptoManager.bellasoEncryption("JAVA TESTING", "JUNIT"));

	}

	@Test
	public void testDecryptBellaso() {
		assertEquals("WOKE WORLD", CryptoManager.bellasoDecryption("Z\\^H#$\"UOQ", "CMSC"));
		assertEquals("JUNIT TESTING", CryptoManager.bellasoDecryption("TV$J^!*F]U_OQ", "JAVA"));
		assertEquals("JAVA TESTING", CryptoManager.bellasoDecryption("TV$J4^Z!]]X\\", "JUNIT"));

	}

}
